# Name:
# BTECH #:

# Import numpy
# Your code here

# Get three pseudo-random sets of integers between -100 and 100
# np.random.seed(1) # UNCOMMENT ME
# array = np.random.randint(-100, 101, 100) # UNCOMMENT ME: You can use this array to test your functions


# ********  QUESTION 1  ********
# Build a function that takes in an array and two integers and returns an array of items greater than the first number and less than the second number?
def getNumbersBetween(array, lowerNumber, higherNumber):
    # Your code here
    return



# ********  QUESTION 2  ********
# Build a function that takes in an array of integers and returns all of the negative numbers EXCEPT for -57
def negativeNumbersExceptNegative57(array):
    # Your code here
    return



# ********  QUESTION 3  ********
# Write a function that takes an array and a number, and retrieves an array of each number immediately to the left and right of that number. 
# The order of the values is not important.
def leftAndRight(array, num):
    # Your code here
    return
