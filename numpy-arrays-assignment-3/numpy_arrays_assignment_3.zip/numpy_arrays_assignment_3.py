# Name:
# BTECH #:

# Import numpy
# Your code here

# Get three pseudo-random sets of integers between -100 and 100
# np.random.seed(1) # UNCOMMENT ME
# array = np.random.randint(-100, 101, 100) # UNCOMMENT ME: You can use this array to test your functions


# ********  QUESTION 1  ********
# Build a function that takes in an array and two integers and returns an array of items greater than the first number and less than the second number?
def getNumbersBetween(array, lowerNumber, higherNumber):
    # Your code here
    return



# ********  QUESTION 2  ********
# Build a function that takes in an array of integers and returns all of the negative numbers EXCEPT for -57
def negativeNumbersExceptNegative57(array):
    # Your code here
    return



# ********  QUESTION 3  ********
# Write a function that takes an array and a number, and retrieves an array of each number immediately to the left and right of that number. 
# The order of the values is not important. Remember that the `.where()` function returns a tuple where the 0th item is the array of indexes.
# Also remember that you can join two arrays together using the NumPy
# concatenate function, where the first argument is a tuple that contains each array to be merged.
# np.concatenate((arr1, arr2))
def leftAndRight(array, num):
    # Your code here
    return
