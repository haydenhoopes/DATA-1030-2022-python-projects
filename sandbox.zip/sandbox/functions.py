def squareRoot(num):
    return num ** 0.5

print(squareRoot(9))
print(squareRoot(16))