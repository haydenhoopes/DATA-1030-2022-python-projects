hawaii = {
    'population': 1.416,
    'capital': 'Honolulu',
    'islands': ["O'ahu", "Maui", "Lana'i", "Kaho'olawe", "Kaua'i", "Hawai'i", "Nashville"],
    'has_beach': True,
    'times_visited': 2
}

# hawaii['times_visited'] = hawaii['times_visited'] + 1
hawaii['times_visited'] += 1

print(hawaii)
