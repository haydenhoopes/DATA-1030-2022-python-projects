cars = ['ferrari', 'lambourghini', 'sherman', 'mustang', 'civic', 'pinto', 'bronco', 'hot wheels']

cars.sort(reverse=True)

# print(cars)






# cars.pop()

# cars.remove('sherman')

# cars.append('aveo')

# more_cars = ['leaf', 'tesla']

# cars.extend(more_cars)

# print(cars)





prime_numbers = [7, 11, 23, 5, 2]

prime_numbers.sort()
print(len(prime_numbers))
print(sum(prime_numbers))