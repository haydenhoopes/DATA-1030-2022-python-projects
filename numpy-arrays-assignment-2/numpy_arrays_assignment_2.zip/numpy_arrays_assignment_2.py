# Name:
# BTECH #:

import numpy as np

# *********  QUESTION 1  *********
# Using indexing, create the following matrix:
# Matrix 1
# [  0  0  1]
# [  0  9  1]
# [  0  0  1]

def createMatrix1():
    # Your code here
    return


# *********  QUESTION 2  *********
# Using indexing, create the following matrix:
# Matrix 2
# [  0  0  0  7  0]
# [  1  1  1  1  1]
# [  3  4  5  4  3]
# [  1  1  1  1  1]
# [  7  0  0  0  0]

def createMatrix2():
    # Your code here
    return


# *********  QUESTION 3  *********
# Using indexing and array methods, create the following matrix:
# Matrix 3
# [  1  0  3  0  3  0  0]
# [  0  1  0  2  2  2  0]
# [  4  4  1  4  4  4  4]
# [  0  0  0  1  0  0  0]
# [  9  9  9  0  1  0  0]
# [  9  9  9  0 10  1  0]
# [  9  9  9  0  0  0  1]

def createMatrix3():
    # Your code here
    return

